# adsclientthread

## Overview
The AdsClienthandler is a minimal python client for Beckhoff TwinCAT ADS communicatuon based on pyADS. This handler manages to periodically read/write all the ads symbols in the ads symbol lis, defined in the configuration.

The user can fully access the ads data via the ads data model.

## Usage
See "example.py" for an example how to use this lib.


